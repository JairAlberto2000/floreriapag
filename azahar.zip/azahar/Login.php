<?php
require ("requester.php");
include 'Conexion.php';

$parametros = json_decode(file_get_contents('php://input'));

$query = mysqli_query($con, "SELECT * FROM user where email = '".$parametros->email."' and contrasena = '".$parametros->contrasena."'");

$cont = mysqli_fetch_assoc($query);

$id= $cont["id"];

if($cont)
{  
    session_id($id.date("mdyhis"));
    session_start();
    $_SESSION["usuario"]=json_encode($cont);
    $query = mysqli_query($con, "UPDATE user SET sesion='".session_id()."' WHERE id=$id ");
    echo json_encode(array("estado"=>true,"tipo"=>$cont["Id_cargo"],"id"=>$cont["id"]));
    exit;
}
echo json_encode(array("estado"=>false));

?>