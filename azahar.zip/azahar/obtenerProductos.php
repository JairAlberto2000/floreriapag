<?php
require ("requester.php");
include 'Conexion.php';
$parametros = json_decode(file_get_contents('php://input'));
//Se inicia sesion 

$query = mysqli_query($con, "SELECT sesion FROM user where id=$parametros->id");
$sesion_id= mysqli_fetch_assoc($query);
$sesion_id=$sesion_id["sesion"];
session_start(array($sesion_id));

$sesion=json_decode($_SESSION["usuario"]);
//Se obtiene el carrito del usuario
$req = mysqli_query($con,"SELECT id FROM carrito WHERE fk_usuario=$sesion->id");
$carrito = mysqli_fetch_assoc($req);
$carrito = $carrito["id"];
//Se obtienen los articulos del carrito
$req = mysqli_query($con,"SELECT * FROM contenido_carrito WHERE fk_carrito=$carrito");
$contenido = [];
if($req){
    while($element = mysqli_fetch_assoc($req)){
        $req2 = mysqli_query($con,"SELECT * FROM productos WHERE id='".$element["fk_producto"]."'");
        $element["producto"]=mysqli_fetch_assoc($req2);
        array_push($contenido,$element);
    }
}
echo json_encode(array(
    "carrito"=>$carrito,
    "productos"=>$contenido
));
?>
