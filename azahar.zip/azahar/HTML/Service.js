async function postRequest(key,data){
    return await fetch("http://localhost/azahar/"+key,{
        method:"POST",
        headers:{
            "Content-Type":"application/json"
        },
        body:JSON.stringify(data)
    }).then(async (response)=>{
        
        return await response.json();;
    })
}