<?php
require ("requester.php");
include 'Conexion.php';

$parametros = json_decode(file_get_contents('php://input'));

$query = mysqli_query($con, "UPDATE user SET sesion='NA' where id=$parametros->id");

echo json_encode(array("estado"=>true));
exit;



