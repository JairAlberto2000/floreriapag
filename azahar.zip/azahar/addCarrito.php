<?php
require ("requester.php");
include 'Conexion.php';

$parametros = json_decode(file_get_contents('php://input'));
$query = mysqli_query($con, "SELECT sesion FROM user where id=$parametros->id");
$sesion_id= mysqli_fetch_assoc($query);
$sesion_id= $sesion_id["sesion"];
session_start(array($sesion_id));

$usuario=json_decode($_SESSION["usuario"]);

$req = mysqli_query($con,"SELECT id FROM productos WHERE id=$parametros->id_producto");
$prod = mysqli_fetch_assoc($req);
 $prod=$prod["id"];
$req = mysqli_query($con,"SELECT id FROM carrito WHERE fk_usuario=$usuario->id");
$carrito = mysqli_fetch_assoc($req);
$carrito=$carrito["id"];
if(!$carrito){
    $req = mysqli_query($con,"INSERT INTO carrito VALUES(NULL,$parametros->id)");
    $id_carrito = mysqli_insert_id($con);
}
//Registrar el producto en el carrito
$creq = mysqli_query($con,"INSERT INTO contenido_carrito VALUES(NULL,$carrito,$prod,$parametros->cantidad)");
$carrito = mysqli_insert_id($con);

echo json_encode(array($carrito));

exit;
?>