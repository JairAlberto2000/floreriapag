<?php
require ("requester.php");
include 'Conexion.php';

$parametros = json_decode(file_get_contents('php://input'));

$query = mysqli_query($con, "SELECT sesion FROM user where id=$parametros->id");

$sesion_id= mysqli_fetch_assoc($query);
$sesion_id= $sesion_id["sesion"];


session_start(array($sesion_id));
$sesion=json_decode($_SESSION["usuario"]);
$query = mysqli_query($con, "SELECT * FROM productos WHERE id=$parametros->id_producto");
echo json_encode(mysqli_fetch_assoc($query));
exit;

?>