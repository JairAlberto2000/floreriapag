<?php
require ("requester.php");
$server = "localhost";
$database = "floreriaelazahar";
$username = "jair";
$contrasena = "123";

$con = mysqli_connect($server, $username, $contrasena, $database);

if (!$con)
{
    echo "Conexión No Exitosa";
}
else
{
    
}

?>