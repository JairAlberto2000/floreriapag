<?php
require ("requester.php");
include("Conexion.php");

$id = $_POST['id'];
$nombrep = $_POST['nombrep'];
$precio = $_POST['precio'];

$sql = mysqli_query($con, "UPDATE productos SET nombrep='$nombrep', precio='$precio' WHERE id='$id'");

header("location: Admin.php");

?>