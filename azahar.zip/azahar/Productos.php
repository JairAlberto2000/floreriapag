<?php
require ("requester.php");
include("Conexion.php");
$sql = mysqli_query($con, "SELECT id, nombrep, precio, imagen FROM productos WHERE 1");
$resultado = mysqli_fetch_all($sql, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edicion</title>
    <link rel="stylesheet" href="/azahar/CSS/estiloPro.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet">
</head>

    <body>

    <nav>
    <input type="checkbox" id="check">
    <label for="check" class="checkbtn">
        <i class="fas fa-bars"></i>
    </label>
    <ul>
        <li><a href="/azahar/HTML/Inicio.html">Inicio</a></li>
        <li><a href="/azahar/Productos.php">Productos</a></li>
        <li><a href="/azahar/HTML/Ubicacion.html">Ubicacion</a></li>
        <li><a href="/azahar/HTML/logout.html">Cerrar Sesion</a></li>
        <li><a href="/azahar/HTML/vistaCarrito.html">Carrito</a></li>
    </ul>
    </nav>

    <section class="products">
		<h2>Productos</h2>
		<div class="all-products">
        <?php
        foreach ($resultado as $row) {
            ?>
                <?php
                    $id = $row['id'];
                    $imagen = $row['imagen'];
                    if (empty($imagen)) {
                        $imagen = "img/productos/no-img.jpg";
                    }
                    ?>
			<form onsubmit='return product(event)' class="product">
                <a><img src="<?php echo $imagen; ?>"></a>
				<div class="product-info">
					<h4 class="product-title">
                        <?php echo $row["nombrep"]; ?>
					</h4>
					<p class="product-price">
                    <span class="precio">$
                            <?php echo $row["precio"]; ?>
                        </span>
                        <input type="hidden"  name="precio" value="<?php echo $row['precio']; ?>">
                        <input type="hidden" id="id_producto" name="id" value="<?php echo $row['id']; ?>">
                    </p>
					<input class="product-btn" type="submit" value="Comprar ahora"></input>

				</div>
            </form>
            <?php
        }
        ?>
        </div>
        <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    </section>
    <script>
        function product(e)
        {
            e.preventDefault()
            localStorage.setItem("id_producto",e.srcElement[1].attributes.value.value);
            window.location.href="html/Producto.html"
        }
    </script>
    <footer id = "Pie">
<a href="https://www.facebook.com/"><img src="/azahar/img/logo_fb.png" alt="Facebook"></a>
<a href="https://www.instagram.com/"><img src="/azahar/img/logo_insta.png" alt="Instagram"></a>
<a href="https://twitter.com/"><img src="/azahar/img/logo_twitter.png" alt="Twitter"></a>
<br>
<p>Jair Alberto Tapia Becerra</p>
    </footer>
</body>
</html>