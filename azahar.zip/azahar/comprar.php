<?php
require ("requester.php");
include 'Conexion.php';
require "sendMail.php";
require './fpdf/fpdf.php';
$parametros = json_decode(file_get_contents('php://input'));
//Se inicia sesion

$query = mysqli_query($con, "SELECT sesion FROM user where id=$parametros->id");
$sesion_id= mysqli_fetch_assoc($query);
$sesion_id= $sesion_id["sesion"];

$query = mysqli_query($con, "SELECT email FROM user where id=$parametros->id");
$correo= mysqli_fetch_assoc($query);
$correo = $correo["email"];

session_start(array($sesion_id));

$query = mysqli_query($con, "SELECT id FROM carrito where fk_usuario=$parametros->id");
$carrito_id= mysqli_fetch_assoc($query);
$carrito_id=$carrito_id["id"];
$query = mysqli_query($con, "INSERT INTO PEDIDO VALUES(NULL,$parametros->id,$parametros->total,CURRENT_TIMESTAMP())");
$pedido_id= mysqli_insert_id($con);

for($i=0;$i<sizeof($parametros->carrito->productos);$i++){
    $query = mysqli_query($con, "INSERT INTO detalles_pedido VALUES(NULL,'".$parametros->carrito->productos[$i]->cantidad."','".$parametros->carrito->productos[$i]->fk_producto."',$pedido_id)");
}
$query = mysqli_query($con, "DELETE FROM contenido_carrito where fk_carrito=$carrito_id");
$pdf = new FPDF();

$pdf->AddPage();

$pdf->SetTitle('Pedido');

$pdf->SetFont('helvetica', '', 10);
foreach ($parametros->carrito->productos as $element) {
    $precio = $element->cantidad*$element->producto->precio;
    $pdf->Cell(40,10, 'Nombre:'.$element->producto->nombrep, 1, 1);
    $pdf->Cell(40,10, 'Precio : ' . $element->producto->precio, 1, 1);
    $pdf->Cell(40,10, 'Cantidad: ' . $element->cantidad, 1, 1);
    $pdf->Cell(40,10, 'SubTotal: ' . $precio , 1, 1);
}
$pdf->Cell(40,10, 'Total: ' . $parametros->total , 0, 1);

$pdf->Output('pdf/orden'.$sesion_id.'.pdf', 'F');
sendMail($sesion_id,$correo);
echo json_encode(array("estado"=>true));
exit;


